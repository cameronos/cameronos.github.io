/*
 * events.c - Event handling
 *
 * Handlers for X11 events including window dragging and Alt+Tab switching.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/keysym.h>
#include "sunwm.h"

/* Handle MapRequest - new window wants to be mapped */
void handle_map_request(WM *wm, XMapRequestEvent *ev)
{
    Client *c;
    XWindowAttributes attr;

    c = client_find(wm, ev->window);
    if (c != NULL) return;

    if (!XGetWindowAttributes(wm->display, ev->window, &attr)) return;
    if (attr.override_redirect) return;

    client_create(wm, ev->window);
}

/* Handle UnmapNotify - window is being unmapped */
void handle_unmap_notify(WM *wm, XUnmapEvent *ev)
{
    Client *c = client_find(wm, ev->window);
    if (c != NULL && ev->window == c->window) {
        client_destroy(wm, c);
    }
}

/* Handle ConfigureRequest - window wants to change size/position */
void handle_configure_request(WM *wm, XConfigureRequestEvent *ev)
{
    Client *c = client_find(wm, ev->window);
    XWindowChanges wc;

    wc.x = ev->x;
    wc.y = ev->y;
    wc.width = ev->width;
    wc.height = ev->height;
    wc.border_width = 0;
    wc.sibling = ev->above;
    wc.stack_mode = ev->detail;

    if (c != NULL) {
        if (ev->value_mask & CWX) c->x = ev->x;
        if (ev->value_mask & CWY) c->y = ev->y;
        if (ev->value_mask & CWWidth) c->width = ev->width;
        if (ev->value_mask & CWHeight) c->height = ev->height;

        XMoveResizeWindow(wm->display, c->frame,
                          c->x,
                          c->y - TITLE_HEIGHT,
                          c->width,
                          c->height + TITLE_HEIGHT);
        XResizeWindow(wm->display, c->title, c->width, TITLE_HEIGHT);
        XMoveResizeWindow(wm->display, c->window,
                          0,
                          TITLE_HEIGHT,
                          c->width, c->height);
        client_draw_title(wm, c);
    } else {
        XConfigureWindow(wm->display, ev->window, ev->value_mask, &wc);
    }
}

/* Handle ButtonPress - start window drag, resize, or button clicks */
void handle_button_press(WM *wm, XButtonEvent *ev)
{
    Client *c;

    // If clicking in the menu
    if (wm->menu.visible && ev->window == wm->menu.window) {
        menu_handle_button_press(wm, ev);
        return;
    }

    // Right-click on root -> show menu
    if (ev->window == wm->root && ev->button == Button3) {
        menu_show(wm, ev->x_root, ev->y_root);
        return;
    }

    // Hide menu if visible
    if (wm->menu.visible) menu_hide(wm);

    // Find the client we clicked in
    c = client_find(wm, ev->window);
    if (!c) return;

    // Focus the client immediately
    client_focus(wm, c);

    // Close button
    if (ev->window == c->close_button) {
        XUngrabPointer(wm->display, CurrentTime);
        wm->drag_client = NULL;
        client_close(wm, c);
        return;
    }

    // Maximize button
    if (ev->window == c->maximize_button) {
        XUngrabPointer(wm->display, CurrentTime);
        wm->drag_client = NULL;
        client_maximize(wm, c);
        return;
    }

    // Resize edges
    wm->resize_edge = client_get_resize_edge(wm, c, ev->x_root, ev->y_root);
    if (wm->resize_edge != RESIZE_NONE) {
        wm->resize_client = c;
        wm->resize_start_x = ev->x_root;
        wm->resize_start_y = ev->y_root;
        wm->resize_start_win_x = c->x;
        wm->resize_start_win_y = c->y;
        wm->resize_start_width = c->width;
        wm->resize_start_height = c->height;

        XGrabPointer(wm->display, c->frame, False,
                     ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
                     GrabModeAsync, GrabModeAsync, None, None, CurrentTime);
        return;
    }

    // Title bar drag
    if (ev->window == c->title) {
        wm->drag_client = c;
        wm->drag_start_x = ev->x_root - c->x;
        wm->drag_start_y = ev->y_root - c->y;

        XGrabPointer(wm->display, c->title, False,
                     ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
                     GrabModeAsync, GrabModeAsync, None, None, CurrentTime);
        return;
    }
}



/* Handle ButtonRelease - end window drag/resize */
void handle_button_release(WM *wm, XButtonEvent *ev)
{
    (void)ev;  // suppress unused parameter warning

    if (wm->drag_client != NULL) {
        XUngrabPointer(wm->display, CurrentTime);
        wm->drag_client = NULL;
    }

    if (wm->resize_client != NULL) {
        XUngrabPointer(wm->display, CurrentTime);
        wm->resize_client = NULL;
        wm->resize_edge = RESIZE_NONE;
    }
}

/* Handle MotionNotify - drag window or update cursor */
void handle_motion_notify(WM *wm, XMotionEvent *ev)
{
    if (wm->resize_client != NULL) {
        client_resize(wm, wm->resize_client, ev->x_root, ev->y_root);
        return;
    }

    if (wm->drag_client != NULL) {
        int new_x = ev->x_root - wm->drag_start_x;
        int new_y = ev->y_root - wm->drag_start_y;

        wm->drag_client->x = new_x;
        wm->drag_client->y = new_y;

        XMoveWindow(wm->display, wm->drag_client->frame,
                    new_x,
                    new_y - TITLE_HEIGHT);
        return;
    }
    
    /* Update cursor based on position for resize indication */
    Client *c = client_find(wm, ev->window);
    if (c != NULL && ev->window == c->frame) {
        int edge = client_get_resize_edge(wm, c, ev->x_root, ev->y_root);
        Cursor cursor;
        
        switch (edge) {
        case RESIZE_TOP:
        case RESIZE_BOTTOM:
            cursor = wm->cursor_resize_ns;
            break;
        case RESIZE_LEFT:
        case RESIZE_RIGHT:
            cursor = wm->cursor_resize_ew;
            break;
        case RESIZE_TOP_LEFT:
        case RESIZE_BOTTOM_RIGHT:
            cursor = wm->cursor_resize_nwse;
            break;
        case RESIZE_TOP_RIGHT:
        case RESIZE_BOTTOM_LEFT:
            cursor = wm->cursor_resize_nesw;
            break;
        default:
            cursor = wm->cursor_normal;
            break;
        }
        
        XDefineCursor(wm->display, c->frame, cursor);
    }
}

/* Handle KeyPress - Alt+Tab and custom shortcuts */
/* Handle KeyPress - Alt+Tab and custom shortcuts */
void handle_key_press(WM *wm, XKeyEvent *ev)
{
    KeySym keysym = XLookupKeysym(ev, 0);
    int i;
    /* Mask out NumLock, CapsLock, and other irrelevant modifiers */
    unsigned int state = ev->state & (ControlMask | Mod1Mask | ShiftMask | Mod4Mask);
    
    // DEBUG: Log every keypress
    FILE *debug = fopen("/tmp/sunwm-keypress.log", "a");
    if (debug) {
        fprintf(debug, "KeyPress: keysym=%lu state=%u (Ctrl=%d Alt=%d Shift=%d Super=%d)\n",
                keysym, state,
                !!(state & ControlMask),
                !!(state & Mod1Mask),
                !!(state & ShiftMask),
                !!(state & Mod4Mask));
        fflush(debug);
    }
    
    /* Check custom shortcuts first */
    for (i = 0; i < wm->num_shortcuts; i++) {
        if (debug) {
            fprintf(debug, "  Checking shortcut #%d: keysym=%lu modifiers=%u\n",
                    i, wm->shortcuts[i].keysym, wm->shortcuts[i].modifiers);
        }
        
        if (keysym == wm->shortcuts[i].keysym && 
            state == wm->shortcuts[i].modifiers) {
            
            if (debug) {
                fprintf(debug, "  MATCH! Executing: %s\n", wm->shortcuts[i].command);
                fclose(debug);
            }
            
            /* Execute shortcut command */
            pid_t pid = fork();
            if (pid == 0) {
                setsid();
                execlp("/bin/sh", "sh", "-c", wm->shortcuts[i].command, NULL);
                _exit(1);
            }
            return;
        }
    }
    
    if (debug) {
        fprintf(debug, "  No match found\n");
        fclose(debug);
    }
    
    /* Alt+Tab window switching */
    if (keysym == XK_Tab && (state & Mod1Mask)) {
        if (wm->focused != NULL && wm->focused->next != NULL)
            client_focus(wm, wm->focused->next);
        else if (wm->clients != NULL)
            client_focus(wm, wm->clients);
    }
}

/* Handle Expose - redraw title bars and menu */
void handle_expose(WM *wm, XExposeEvent *ev)
{
    if (ev->count != 0) return;

    if (ev->window == wm->menu.window) {
        menu_draw(wm);
        return;
    }

    Client *c = client_find(wm, ev->window);
    if (c != NULL) {
        if (ev->window == c->title) client_draw_title(wm, c);
        else if (ev->window == c->close_button || ev->window == c->maximize_button)
            client_draw_buttons(wm, c);
    }
}

void handle_enter_notify(WM *wm, XCrossingEvent *ev)
{
    // Remove client_focus() here — hover no longer changes focus
    // Optionally redraw title for window under pointer
    Client *c = client_find(wm, ev->window);
    if (c) client_draw_title(wm, c);
}