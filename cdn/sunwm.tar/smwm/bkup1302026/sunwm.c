/*
 * sunwm.c - SunOS-inspired Window Manager
 *
 * Main window manager implementation following Sun C coding standards.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "sunwm.h"

/*
 * Error handler for X errors
 */
static int
x_error_handler(Display *display, XErrorEvent *ev)
{
	char msg[80];
	
	XGetErrorText(display, ev->error_code, msg, sizeof(msg));
	fprintf(stderr, "X Error: %s\n", msg);
	fprintf(stderr, "  Request: %d, Resource: 0x%lx\n",
		ev->request_code, ev->resourceid);
	
	return (0);
}

/*
 * Initialize the window manager
 */
/*
 * Initialize the window manager
 */
void
wm_init(WM *wm, char *display_name)
{
	XSetWindowAttributes	attrs;
	
	memset(wm, 0, sizeof(WM));
	
	/* Set default border width */
	wm->border_width = BORDER_WIDTH;
	
	/* Open display */
	wm->display = XOpenDisplay(display_name);
	if (wm->display == NULL) {
		fprintf(stderr, "Cannot open display %s\n",
			XDisplayName(display_name));
		exit(1);
	}
	
	wm->screen = DefaultScreen(wm->display);
	wm->root = RootWindow(wm->display, wm->screen);
	
	/* Set error handler */
	XSetErrorHandler(x_error_handler);
	
	/* Select events on root window */
	attrs.event_mask = SubstructureRedirectMask |
			   SubstructureNotifyMask |
			   KeyPressMask;
	XChangeWindowAttributes(wm->display, wm->root,
				CWEventMask, &attrs);
	XSync(wm->display, False);
	
	/* Load font */
	wm->font = XLoadQueryFont(wm->display,
		"-*-helvetica-bold-r-*-*-12-*-*-*-*-*-*-*");
	if (wm->font == NULL) {
		wm->font = XLoadQueryFont(wm->display, "fixed");
	}
	
	/* Create GC */
	wm->gc = XCreateGC(wm->display, wm->root, 0, NULL);
	XSetFont(wm->display, wm->gc, wm->font->fid);
	
	/* Create cursor */
	wm_create_cursor(wm);
	
	/* Create resize cursors */
	wm->cursor_normal = wm->cursor;
	wm->cursor_resize_ns = XCreateFontCursor(wm->display, XC_sb_v_double_arrow);
	wm->cursor_resize_ew = XCreateFontCursor(wm->display, XC_sb_h_double_arrow);
	wm->cursor_resize_nwse = XCreateFontCursor(wm->display, XC_bottom_right_corner);
	wm->cursor_resize_nesw = XCreateFontCursor(wm->display, XC_bottom_left_corner);
	
	/* Define root window cursor */
	XDefineCursor(wm->display, wm->root, wm->cursor);
	
	/* Initialize menu first */
	menu_init(wm);

	/* Load colors and menu items from ~/.sunrc */
	menu_load_rc(wm);

	/* Now set root background from loaded color */
	XSetWindowBackground(wm->display, wm->root, wm->bg_color);
	XClearWindow(wm->display, wm->root);
	
	/* Initialize atoms */
	wm->wm_protocols = XInternAtom(wm->display, "WM_PROTOCOLS", False);
	wm->wm_delete_window = XInternAtom(wm->display,
					   "WM_DELETE_WINDOW", False);
	wm->wm_state = XInternAtom(wm->display, "WM_STATE", False);
	
	/* Grab Alt+Tab for window switching */
	XGrabKey(wm->display, XKeysymToKeycode(wm->display, XK_Tab),
		 Mod1Mask, wm->root, True, GrabModeAsync, GrabModeAsync);
	
	/* Grab Button3 (right-click) on root for menu */
	XGrabButton(wm->display, Button3, AnyModifier, wm->root,
		    True, ButtonPressMask, GrabModeAsync, GrabModeAsync,
		    None, None);
}


/*
 * Cleanup and shutdown
 */
void
wm_cleanup(WM *wm)
{
	Client	*c;
	Client	*next;
	
	/* Destroy all clients */
	for (c = wm->clients; c != NULL; c = next) {
		next = c->next;
		client_destroy(wm, c);
	}
	
	/* Cleanup menu */
	menu_cleanup(wm);
	
	/* Free cursor */
	if (wm->cursor) {
		XFreeCursor(wm->display, wm->cursor);
	}
	
	/* Free resources */
	if (wm->font != NULL) {
		XFreeFont(wm->display, wm->font);
	}
	
	XFreeGC(wm->display, wm->gc);
	XCloseDisplay(wm->display);
}

/*
 * Main event loop
 */
void
wm_run(WM *wm)
{
	XEvent	ev;
	
	for (;;) {
		XNextEvent(wm->display, &ev);
		wm_handle_event(wm, &ev);
	}
}

/*
 * Event dispatcher
 */
void
wm_handle_event(WM *wm, XEvent *ev)
{
	switch (ev->type) {
	case MapRequest:
		handle_map_request(wm, &ev->xmaprequest);
		break;
		
	case UnmapNotify:
		handle_unmap_notify(wm, &ev->xunmap);
		break;
		
	case ConfigureRequest:
		handle_configure_request(wm, &ev->xconfigurerequest);
		break;
		
	case ButtonPress:
		handle_button_press(wm, &ev->xbutton);
		break;
		
	case ButtonRelease:
		handle_button_release(wm, &ev->xbutton);
		break;
		
	case MotionNotify:
		handle_motion_notify(wm, &ev->xmotion);
		break;
		
	case KeyPress:
		handle_key_press(wm, &ev->xkey);
		break;
		
	case Expose:
		handle_expose(wm, &ev->xexpose);
		break;
		
	case EnterNotify:
		handle_enter_notify(wm, &ev->xcrossing);
		break;
	
    case LeaveNotify:
        // Hide menu if pointer leaves menu window
        if (wm->menu.visible && ev->xcrossing.window == wm->menu.window) {
            menu_hide(wm);
        }

        // Optionally, you could redraw the title for the previously focused client
        Client *c_leave = client_find(wm, ev->xcrossing.window);
        if (c_leave != NULL) {
            client_draw_title(wm, c_leave);
        }
        break;

	}
}

/*
 * Get color by name
 */
unsigned long
get_color(Display *display, int screen, const char *color_name)
{
	XColor		color;
	Colormap	colormap;
	
	colormap = DefaultColormap(display, screen);
	
	if (!XParseColor(display, colormap, color_name, &color)) {
		fprintf(stderr, "Cannot parse color: %s\n", color_name);
		return (BlackPixel(display, screen));
	}
	
	if (!XAllocColor(display, colormap, &color)) {
		fprintf(stderr, "Cannot allocate color: %s\n", color_name);
		return (BlackPixel(display, screen));
	}
	
	return (color.pixel);
}

/*
 * Draw 3D Motif-style box
 */
void
draw_3d_box(Display *display, Window win, GC gc,
	    int x, int y, int w, int h,
	    unsigned long light, unsigned long dark,
	    int pressed)
{
	unsigned long	top_color;
	unsigned long	bottom_color;
	
	/* Swap colors if pressed */
	if (pressed) {
		top_color = dark;
		bottom_color = light;
	} else {
		top_color = light;
		bottom_color = dark;
	}
	
	/* Draw top and left edges (light) */
	XSetForeground(display, gc, top_color);
	XDrawLine(display, win, gc, x, y, x + w - 1, y);
	XDrawLine(display, win, gc, x, y, x, y + h - 1);
	XDrawLine(display, win, gc, x + 1, y + 1, x + w - 2, y + 1);
	XDrawLine(display, win, gc, x + 1, y + 1, x + 1, y + h - 2);
	
	/* Draw bottom and right edges (dark) */
	XSetForeground(display, gc, bottom_color);
	XDrawLine(display, win, gc, x, y + h - 1, x + w - 1, y + h - 1);
	XDrawLine(display, win, gc, x + w - 1, y, x + w - 1, y + h - 1);
	XDrawLine(display, win, gc, x + 1, y + h - 2, x + w - 2, y + h - 2);
	XDrawLine(display, win, gc, x + w - 2, y + 1, x + w - 2, y + h - 2);
}

/*
 * Create cursor - just use standard X11 cursor
 */
void wm_create_cursor(WM *wm)
{
    wm->cursor = XCreateFontCursor(wm->display, XC_left_ptr);
}


/*
 * Main entry point
 */
int
main(int argc, char **argv)
{
	WM		wm;
	char		*display_name;
	
	display_name = (argc > 1) ? argv[1] : NULL;
	
	printf("SunWM - SunOS-inspired Window Manager\n");
	printf("Starting on display %s\n", XDisplayName(display_name));
	
	wm_init(&wm, display_name);
	wm_run(&wm);
	wm_cleanup(&wm);
	
	return (0);
}