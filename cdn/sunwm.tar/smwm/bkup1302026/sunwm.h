/*
 * sunwm.h - SunOS-inspired Window Manager
 *
 * Copyright (c) 2026
 * 
 * A window manager inspired by classic SunOS/Solaris window managers,
 * following the C Style and Coding Standards for SunOS.
 */

#ifndef _SUNWM_H
#define _SUNWM_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/cursorfont.h>

/*
 * Constants
 */
#define MAX_WINDOWS		256
#define MAX_MENU_ITEMS		32
#define TITLE_HEIGHT		25
#define BORDER_WIDTH		3
#define MANUAL_BORDER 3
#define BUTTON_SIZE		18
#define BUTTON_MARGIN		3
#define MENU_ITEM_HEIGHT	25
#define MENU_WIDTH		200
#define RC_FILE			".sunrc"
#define RESIZE_MARGIN		12
#define MIN_WINDOW_WIDTH	65
#define MIN_WINDOW_HEIGHT	35

/*
 * Resize edges/corners
 */
#define RESIZE_NONE		0
#define RESIZE_TOP		1
#define RESIZE_BOTTOM		2
#define RESIZE_LEFT		4
#define RESIZE_RIGHT		8
#define RESIZE_TOP_LEFT		(RESIZE_TOP | RESIZE_LEFT)
#define RESIZE_TOP_RIGHT	(RESIZE_TOP | RESIZE_RIGHT)
#define RESIZE_BOTTOM_LEFT	(RESIZE_BOTTOM | RESIZE_LEFT)
#define RESIZE_BOTTOM_RIGHT	(RESIZE_BOTTOM | RESIZE_RIGHT)

/*
 * Max keyboard shortcuts
 */
#define MAX_SHORTCUTS		32

/*
 * lavender Colors
 */
#define BG_COLOR           "#1B1A2F"  /* deep dark purple background */
#define TITLE_BG_ACTIVE    "#5D4B8B"  /* muted lavender title active */
#define TITLE_BG_INACTIVE  "#2E294E"  /* dark bluish-purple inactive */
#define TITLE_FG           "#E6E0F8"  /* soft lavender text */
#define BORDER_LIGHT       "#3E3B55"  /* highlight border */
#define BORDER_DARK        "#0F0E1F"  /* shadow border */
#define BORDER_COLOR       "#5D4B8B"  /* main border color */

/*
 * Menu item structure
 */
typedef struct _menu_item {
	char			*label;
	char			*command;
} MenuItem;

/*
 * Keyboard shortcut structure
 */
typedef struct {
	unsigned int		modifiers;	/* Mod1Mask | ControlMask, etc */
	KeySym			keysym;		/* XK_t, etc */
	char			*command;	/* command to execute */
} Shortcut;

/*
 * Root menu structure
 */
typedef struct {
    Window window;
    char *title;             /* menu title */
    MenuItem items[MAX_MENU_ITEMS];
    int num_items;
    int selected;
    int visible;
} Menu;


/*
 * Client window structure
 */
typedef struct _client {
	Window			window;		/* client window */
	Window			frame;		/* frame window */
	Window			title;		/* title bar window */
	Window			close_button;	/* close button */
	Window			maximize_button;/* maximize button */
	int			x;
	int			y;
	unsigned int		width;
	unsigned int		height;
	int			saved_x;	/* for maximize */
	int			saved_y;
	unsigned int		saved_width;
	unsigned int		saved_height;
	int			maximized;
	char			*name;		/* window title */
    int focused;
	struct _client		*next;
} Client;

/*
 * Window manager state
 */
typedef struct {
	Display			*display;
	int			screen;
	Window			root;
	Client			*clients;
	Client			*focused;
	GC			gc;
	Menu			menu;
	Cursor			cursor;
	
	/* Shortcuts */
	Shortcut		shortcuts[MAX_SHORTCUTS];
	int			num_shortcuts;
	
	/* Colors */
	unsigned long		bg_color;
	unsigned long		title_bg_active;
	unsigned long		title_bg_inactive;
	unsigned long		title_fg;
	unsigned long		border_light;
	unsigned long		border_dark;
	unsigned long		border_color;
    unsigned long		border_active;
    unsigned long		border_inactive;
	
	/* Border width (configurable via .sunrc) */
	int			border_width;
	
	/* Fonts */
	XFontStruct		*font;
	
	/* Atoms */
	Atom			wm_protocols;
	Atom			wm_delete_window;
	Atom			wm_state;
	
	/* Cursors */
	Cursor			cursor_normal;
	Cursor			cursor_resize_ns;
	Cursor			cursor_resize_ew;
	Cursor			cursor_resize_nwse;
	Cursor			cursor_resize_nesw;
	
	/* Drag state */
	int			drag_start_x;
	int			drag_start_y;
	Client			*drag_client;
	
	/* Resize state */
	int			resize_start_x;	/* mouse x */
	int			resize_start_y;	/* mouse y */
	int			resize_start_win_x;	/* window x */
	int			resize_start_win_y;	/* window y */
	int			resize_start_width;
	int			resize_start_height;
	Client			*resize_client;
	int			resize_edge;	/* which edge/corner */
} WM;

/*
 * Function prototypes
 */
void		wm_init(WM *wm, char *display_name);
void		wm_cleanup(WM *wm);
void		wm_run(WM *wm);
void		wm_handle_event(WM *wm, XEvent *ev);
void		wm_create_cursor(WM *wm);

Client		*client_create(WM *wm, Window w);
void		client_destroy(WM *wm, Client *c);
Client		*client_find(WM *wm, Window w);
void		client_focus(WM *wm, Client *c);
void		client_draw_title(WM *wm, Client *c);
void		client_draw_border(WM *wm, Client *c);
void		client_raise(WM *wm, Client *c);
void		client_close(WM *wm, Client *c);
void		client_maximize(WM *wm, Client *c);
void		client_draw_buttons(WM *wm, Client *c);
int		client_get_resize_edge(WM *wm, Client *c, int x, int y);
void		client_resize(WM *wm, Client *c, int x, int y);
void		client_update_cursor(WM *wm, Client *c, Window w, int x, int y);

void		menu_init(WM *wm);
void		menu_cleanup(WM *wm);
void		menu_load_rc(WM *wm);
void		menu_add_default(WM *wm);
void		menu_show(WM *wm, int x, int y);
void		menu_hide(WM *wm);
void		menu_draw(WM *wm);
void		menu_handle_button_press(WM *wm, XButtonEvent *ev);
void		menu_handle_motion(WM *wm, XMotionEvent *ev);
void		menu_execute(WM *wm, int item);

void		handle_map_request(WM *wm, XMapRequestEvent *ev);
void		handle_unmap_notify(WM *wm, XUnmapEvent *ev);
void		handle_configure_request(WM *wm, XConfigureRequestEvent *ev);
void		handle_button_press(WM *wm, XButtonEvent *ev);
void		handle_button_release(WM *wm, XButtonEvent *ev);
void		handle_motion_notify(WM *wm, XMotionEvent *ev);
void		handle_key_press(WM *wm, XKeyEvent *ev);
void		handle_expose(WM *wm, XExposeEvent *ev);
void		handle_enter_notify(WM *wm, XCrossingEvent *ev);

unsigned long	get_color(Display *display, int screen, const char *color_name);
void		draw_3d_box(Display *display, Window win, GC gc,
			    int x, int y, int w, int h,
			    unsigned long light, unsigned long dark,
			    int pressed);

#endif /* _SUNWM_H */