/*
 * client.c - Client window management
 *
 * Functions for managing client windows with Motif-style decorations.
 */

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include "sunwm.h"

Client *client_create(WM *wm, Window w) {
    Client *c;
    XWindowAttributes attr, root_attr;
    XSetWindowAttributes frame_attr;
    XTextProperty text_prop;

    c = (Client *)malloc(sizeof(Client));
    if (!c) return NULL;
    memset(c, 0, sizeof(Client));

    c->window = w;
    c->maximized = 0;

    if (!XGetWindowAttributes(wm->display, w, &attr)) {
        free(c);
        return NULL;
    }
    XGetWindowAttributes(wm->display, wm->root, &root_attr);

    c->width = attr.width;
    c->height = attr.height;

    // --- Cascade positioning ---
    int cascade_offset = 30;
    int num_windows = 0;
    for (Client *tmp = wm->clients; tmp; tmp = tmp->next) num_windows++;

    c->x = 50 + num_windows * cascade_offset;
    c->y = 50 + num_windows * cascade_offset;

    // Wrap if off screen
    if (c->x + c->width > root_attr.width) c->x = 50;
    if (c->y + c->height + TITLE_HEIGHT > root_attr.height) c->y = 50;

    // --- Window name ---
    if (XGetWMName(wm->display, w, &text_prop)) {
        c->name = strdup((char *)text_prop.value);
        XFree(text_prop.value);
    } else {
        c->name = strdup("Untitled");
    }

    // --- Frame window ---
    frame_attr.background_pixel = wm->title_bg_inactive;
    frame_attr.event_mask = SubstructureRedirectMask |
                            SubstructureNotifyMask |
                            ButtonPressMask |
                            ButtonReleaseMask |
                            Button1MotionMask |
                            PointerMotionMask |
                            EnterWindowMask |
                            ExposureMask;

    c->frame = XCreateWindow(
        wm->display, wm->root,
        c->x, c->y,
        c->width, c->height + TITLE_HEIGHT,
        wm->border_width,
        CopyFromParent, InputOutput, CopyFromParent,
        CWBackPixel | CWEventMask, &frame_attr
    );

    // --- Title bar ---
    c->title = XCreateWindow(
        wm->display, c->frame,
        0, 0,
        c->width, TITLE_HEIGHT,
        0,
        CopyFromParent, InputOutput, CopyFromParent,
        CWBackPixel | CWEventMask, &frame_attr
    );

    // --- Buttons ---
    c->close_button = XCreateWindow(
        wm->display, c->title,
        c->width - BUTTON_SIZE - BUTTON_MARGIN, BUTTON_MARGIN,
        BUTTON_SIZE, BUTTON_SIZE,
        0, CopyFromParent, InputOutput, CopyFromParent,
        CWBackPixel | CWEventMask, &frame_attr
    );

    c->maximize_button = XCreateWindow(
        wm->display, c->title,
        c->width - 2 * (BUTTON_SIZE + BUTTON_MARGIN), BUTTON_MARGIN,
        BUTTON_SIZE, BUTTON_SIZE,
        0, CopyFromParent, InputOutput, CopyFromParent,
        CWBackPixel | CWEventMask, &frame_attr
    );

    // --- Reparent client ---
    XReparentWindow(wm->display, w, c->frame, 0, TITLE_HEIGHT);

    // --- Add to client list ---
    c->next = wm->clients;
    wm->clients = c;

    // --- Save context ---
    XSaveContext(wm->display, c->frame, 0, (XPointer)c);
    XSaveContext(wm->display, c->title, 0, (XPointer)c);
    XSaveContext(wm->display, c->window, 0, (XPointer)c);
    XSaveContext(wm->display, c->close_button, 0, (XPointer)c);
    XSaveContext(wm->display, c->maximize_button, 0, (XPointer)c);

    // --- Map windows ---
    XMapWindow(wm->display, c->close_button);
    XMapWindow(wm->display, c->maximize_button);
    XMapWindow(wm->display, c->title);
    XMapWindow(wm->display, c->frame);
    XMapWindow(wm->display, w);

    client_draw_title(wm, c);
    client_draw_buttons(wm, c);
    client_draw_border(wm, c);
    client_focus(wm, c);

    return c;
}


/*
 * Destroy a client
 */
void
client_destroy(WM * wm, Client * c) {
  Client * curr;
  Client * prev;

  if (c == NULL) {
    return;
  }

  /* Remove from client list */
  prev = NULL;
  for (curr = wm -> clients; curr != NULL; curr = curr -> next) {
    if (curr == c) {
      if (prev == NULL) {
        wm -> clients = c -> next;
      } else {
        prev -> next = c -> next;
      }
      break;
    }
    prev = curr;
  }

  /* Clear focus if this was the focused window */
  if (wm -> focused == c) {
    wm -> focused = NULL;
  }

  /* Delete contexts */
  XDeleteContext(wm -> display, c -> frame, 0);
  XDeleteContext(wm -> display, c -> title, 0);
  XDeleteContext(wm -> display, c -> window, 0);
  XDeleteContext(wm -> display, c -> close_button, 0);
  XDeleteContext(wm -> display, c -> maximize_button, 0);

  /* Destroy windows */
  XDestroyWindow(wm -> display, c -> frame);

  /* Free memory */
  if (c -> name != NULL) {
    free(c -> name);
  }
  free(c);
}

/*
 * Find a client by window ID
 */
Client *
  client_find(WM * wm, Window w) {
    Client * c;
    XPointer ptr;

    /* Try to find via context */
    if (XFindContext(wm -> display, w, 0, & ptr) == 0) {
      return ((Client * ) ptr);
    }

    /* Search manually */
    for (c = wm -> clients; c != NULL; c = c -> next) {
      if (c -> window == w || c -> frame == w || c -> title == w ||
        c -> close_button == w || c -> maximize_button == w) {
        return (c);
      }
    }

    return (NULL);
  }
  
void update_all_clients_focus_state(WM * wm) {
  for (Client * c = wm -> clients; c; c = c -> next) {
    XSetWindowBackground(wm -> display, c -> title, c == wm -> focused ? wm -> title_bg_active : wm -> title_bg_inactive);
    XSetWindowBackground(wm -> display, c -> close_button, c == wm -> focused ? wm -> title_bg_active : wm -> title_bg_inactive);
    XSetWindowBackground(wm -> display, c -> maximize_button, c == wm -> focused ? wm -> title_bg_active : wm -> title_bg_inactive);
    XClearWindow(wm -> display, c -> title);
    XClearWindow(wm -> display, c -> close_button);
    XClearWindow(wm -> display, c -> maximize_button);
    client_draw_title(wm, c);
    client_draw_buttons(wm, c);
    client_draw_border(wm, c);
  }
  XFlush(wm -> display);
}

void client_focus(WM * wm, Client * c) {
  if (!c) return;
  wm -> focused = c;
  XSetWindowBackground(wm -> display, c -> title, wm -> title_bg_active);
  XClearWindow(wm -> display, c -> title);
  XSetWindowBackground(wm -> display, c -> close_button, wm -> title_bg_active);
  XClearWindow(wm -> display, c -> close_button);
  XSetWindowBackground(wm -> display, c -> maximize_button, wm -> title_bg_active);
  XClearWindow(wm -> display, c -> maximize_button);
  client_draw_title(wm, c);
  client_draw_buttons(wm, c);
  client_draw_border(wm, c);
  XRaiseWindow(wm -> display, c -> frame);
  XRaiseWindow(wm -> display, c -> title);
  XRaiseWindow(wm -> display, c -> close_button);
  XRaiseWindow(wm -> display, c -> maximize_button);
  XSetInputFocus(wm -> display, c -> window, RevertToPointerRoot, CurrentTime);
  update_all_clients_focus_state(wm);
}

void client_draw_border(WM *wm, Client *c) {
    if (!c) return;

    /* Use X11's native border color setting */
    unsigned long color = (c == wm->focused) ? wm->border_light : wm->border_dark;
    XSetWindowBorder(wm->display, c->frame, color);
}

/*
 * Draw client title bar
 */
void client_draw_title(WM * wm, Client * c) {
  if (!c) return;

  unsigned long bg_color = (c == wm -> focused) ? wm -> title_bg_active : wm -> title_bg_inactive;
  unsigned long text_color = (c == wm -> focused) ? WhitePixel(wm -> display, wm -> screen) : BlackPixel(wm -> display, wm -> screen);

  /* Explicitly fill title background */
  XSetForeground(wm -> display, wm -> gc, bg_color);
  XFillRectangle(wm -> display, c -> title, wm -> gc, 0, 0, c -> width, TITLE_HEIGHT);

  /* Draw 3D border */
  draw_3d_box(wm -> display, c -> title, wm -> gc,
    0, 0, c -> width, TITLE_HEIGHT,
    wm -> border_light, wm -> border_dark, 0);

  /* Draw title text */
  if (c -> name) {
    int text_width = XTextWidth(wm -> font, c -> name, strlen(c -> name));
    int text_x = (c -> width - text_width) / 2;
    int text_y = (TITLE_HEIGHT + wm -> font -> ascent - wm -> font -> descent) / 2;

    XSetForeground(wm -> display, wm -> gc, text_color);
    XDrawString(wm -> display, c -> title, wm -> gc, text_x, text_y,
      c -> name, strlen(c -> name));
  }
}

/*
 * Raise a client window to the top
 */
void
client_raise(WM * wm, Client * c) {
  if (c == NULL) {
    return;
  }

  XRaiseWindow(wm -> display, c -> frame);
}

/*
 * Close a client window
 */
void client_close(WM * wm, Client * c) {
  if (!c) return;

  // Send WM_DELETE_WINDOW or kill the client
  XEvent ev;
  memset( & ev, 0, sizeof(ev));
  ev.type = ClientMessage;
  ev.xclient.window = c -> window;
  ev.xclient.message_type = wm -> wm_protocols;
  ev.xclient.format = 32;
  ev.xclient.data.l[0] = wm -> wm_delete_window;
  ev.xclient.data.l[1] = CurrentTime;

  if (!XSendEvent(wm -> display, c -> window, False, 0, & ev)) {
    XKillClient(wm -> display, c -> window);
  }

  // Remove client from linked list
  Client ** prev = & wm -> clients;
  while ( * prev && * prev != c) {
    prev = & ( * prev) -> next;
  }
  if ( * prev == c) {
    * prev = c -> next;
  }

  // If the client was focused, pick another client
  if (wm -> focused == c) {
    wm -> focused = NULL;
    if (wm -> clients) {
      // Focus first remaining client
      client_focus(wm, wm -> clients);
    }
  }

  // Destroy windows
  XDestroyWindow(wm -> display, c -> frame);
  XDestroyWindow(wm -> display, c -> title);
  XDestroyWindow(wm -> display, c -> close_button);
  XDestroyWindow(wm -> display, c -> maximize_button);
  XDestroyWindow(wm -> display, c -> window);

  // Free allocated memory
  if (c -> name) free(c -> name);
  free(c);

  // Optional: redraw remaining clients to update highlights
  for (Client * cl = wm -> clients; cl != NULL; cl = cl -> next) {
    client_draw_title(wm, cl);
    client_draw_buttons(wm, cl);
  }
}

/*
 * Maximize/unmaximize a client window
 */
void client_maximize(WM * wm, Client * c) {
  XWindowAttributes root_attr;

  if (c == NULL) return;

  if (c -> maximized) {
    // Restore original size
    c -> x = c -> saved_x;
    c -> y = c -> saved_y;
    c -> width = c -> saved_width;
    c -> height = c -> saved_height;
    c -> maximized = 0;
  } else {
    // Save current geometry
    c -> saved_x = c -> x;
    c -> saved_y = c -> y;
    c -> saved_width = c -> width;
    c -> saved_height = c -> height;

    // Get root window size
    XGetWindowAttributes(wm -> display, wm -> root, & root_attr);

    // Maximize: leave room for title bar
    c -> x = 0;
    c -> y = TITLE_HEIGHT;
    c -> width = root_attr.width;
    c -> height = root_attr.height - TITLE_HEIGHT;
    c -> maximized = 1;
  }

  // Resize frame window (includes title + client)
  XMoveResizeWindow(wm -> display, c -> frame,
    c -> x,
    c -> y - TITLE_HEIGHT,
    c -> width,
    c -> height + TITLE_HEIGHT);

  // Resize title bar (always at top of frame)
  XResizeWindow(wm -> display, c -> title, c -> width, TITLE_HEIGHT);

  // Reposition buttons inside title bar
  XMoveWindow(wm -> display, c -> close_button,
    c -> width - BUTTON_SIZE - BUTTON_MARGIN,
    BUTTON_MARGIN);
  XMoveWindow(wm -> display, c -> maximize_button,
    c -> width - 2 * (BUTTON_SIZE + BUTTON_MARGIN),
    BUTTON_MARGIN);

  // Resize client window inside frame, below title bar
  XMoveResizeWindow(wm -> display, c -> window,
    0,
    TITLE_HEIGHT,
    c -> width, c -> height);

  // Ensure title bar and buttons are on top
  XRaiseWindow(wm -> display, c -> title);
  XRaiseWindow(wm -> display, c -> close_button);
  XRaiseWindow(wm -> display, c -> maximize_button);

  client_draw_title(wm, c);
  client_draw_buttons(wm, c);

  XSync(wm -> display, False);
}

/*
 * Draw window control buttons
 */
void client_draw_buttons(WM * wm, Client * c) {
  if (!c) return;

  unsigned long bg_color = (c == wm -> focused) ? wm -> title_bg_active : wm -> title_bg_inactive;

  /* Close button */
  XSetForeground(wm -> display, wm -> gc, bg_color);
  XFillRectangle(wm -> display, c -> close_button, wm -> gc, 0, 0, BUTTON_SIZE, BUTTON_SIZE);
  draw_3d_box(wm -> display, c -> close_button, wm -> gc,
    0, 0, BUTTON_SIZE, BUTTON_SIZE,
    wm -> border_light, wm -> border_dark, 0);

  XSetForeground(wm -> display, wm -> gc, wm -> title_fg);
  XDrawLine(wm -> display, c -> close_button, wm -> gc, 4, 4, BUTTON_SIZE - 5, BUTTON_SIZE - 5);
  XDrawLine(wm -> display, c -> close_button, wm -> gc, BUTTON_SIZE - 5, 4, 4, BUTTON_SIZE - 5);

  /* Maximize button */
  XSetForeground(wm -> display, wm -> gc, bg_color);
  XFillRectangle(wm -> display, c -> maximize_button, wm -> gc, 0, 0, BUTTON_SIZE, BUTTON_SIZE);
  draw_3d_box(wm -> display, c -> maximize_button, wm -> gc,
    0, 0, BUTTON_SIZE, BUTTON_SIZE,
    wm -> border_light, wm -> border_dark, 0);

  XSetForeground(wm -> display, wm -> gc, wm -> title_fg);
  if (c -> maximized) {
    XDrawRectangle(wm -> display, c -> maximize_button, wm -> gc, 5, 6, 7, 7);
    XDrawRectangle(wm -> display, c -> maximize_button, wm -> gc, 7, 4, 7, 7);
  } else {
    XDrawRectangle(wm -> display, c -> maximize_button, wm -> gc, 5, 5, 8, 8);
    for (int i = 0; i < 2; i++)
      XDrawLine(wm -> display, c -> maximize_button, wm -> gc, 5, 5 + i, 13, 5 + i);
  }
}

int client_get_resize_edge(WM *wm, Client *c, int x, int y)
{
    int edge = RESIZE_NONE;
    int frame_x, frame_y;
    unsigned int frame_width, frame_height;
    Window root, child;
    int root_x, root_y;
    unsigned int mask;

    if (!c)
        return RESIZE_NONE;

    /* Get pointer relative to frame */
    XQueryPointer(wm->display, c->frame, &root, &child,
                  &root_x, &root_y, &frame_x, &frame_y, &mask);

    frame_width = c->width;
    frame_height = c->height + TITLE_HEIGHT;

    /* Horizontal edges */
    if (frame_x < RESIZE_MARGIN)
        edge |= RESIZE_LEFT;
    else if (frame_x > (int)(frame_width - RESIZE_MARGIN))
        edge |= RESIZE_RIGHT;

    /* Vertical edges */
    if (frame_y < RESIZE_MARGIN) {
        /* Only allow top-left corner to resize */
        if (frame_x < RESIZE_MARGIN) {
            edge |= RESIZE_TOP;      // top-left corner allowed
            edge |= RESIZE_LEFT;
        }
        // otherwise do NOT allow top-edge resize
    } else if (frame_y > (int)(frame_height - RESIZE_MARGIN)) {
        edge |= RESIZE_BOTTOM;
    }

    return edge;
}

void client_resize(WM *wm, Client *c, int x, int y) {
    if (!c || c != wm->resize_client || c->maximized) return;

    int dx = x - wm->resize_start_x;
    int dy = y - wm->resize_start_y;

    int new_x = c->x;
    int new_y = c->y;
    unsigned int new_width = c->width;
    unsigned int new_height = c->height;

    // Horizontal resize
    if (wm->resize_edge & RESIZE_LEFT) {
        new_width = wm->resize_start_width - dx;
        new_x = wm->resize_start_win_x + dx;
        if ((int)new_width < MIN_WINDOW_WIDTH) {
            new_x = c->x + (c->width - MIN_WINDOW_WIDTH);
            new_width = MIN_WINDOW_WIDTH;
        }
    } else if (wm->resize_edge & RESIZE_RIGHT) {
        new_width = wm->resize_start_width + dx;
        if ((int)new_width < MIN_WINDOW_WIDTH) new_width = MIN_WINDOW_WIDTH;
    }

    // Vertical resize
    if (wm->resize_edge & RESIZE_TOP) {
        new_height = wm->resize_start_height - dy;
        new_y = wm->resize_start_win_y + dy;
        if ((int)new_height < MIN_WINDOW_HEIGHT) {
            new_y = c->y + (c->height - MIN_WINDOW_HEIGHT);
            new_height = MIN_WINDOW_HEIGHT;
        }
    } else if (wm->resize_edge & RESIZE_BOTTOM) {
        new_height = wm->resize_start_height + dy;
        if ((int)new_height < MIN_WINDOW_HEIGHT) new_height = MIN_WINDOW_HEIGHT;
    }

    // Only update if changed
    if (new_x == c->x && new_y == c->y &&
        new_width == c->width && new_height == c->height)
        return;

    c->x = new_x; c->y = new_y;
    c->width = new_width; c->height = new_height;

    XMoveResizeWindow(wm->display, c->frame, c->x, c->y - TITLE_HEIGHT, c->width, c->height + TITLE_HEIGHT);
    XMoveResizeWindow(wm->display, c->window, 0, TITLE_HEIGHT, c->width, c->height);
    XResizeWindow(wm->display, c->title, c->width, TITLE_HEIGHT);
    XMoveWindow(wm->display, c->close_button, c->width - BUTTON_SIZE - BUTTON_MARGIN, BUTTON_MARGIN);
    XMoveWindow(wm->display, c->maximize_button, c->width - 2 * (BUTTON_SIZE + BUTTON_MARGIN), BUTTON_MARGIN);

    client_draw_title(wm, c);
    client_draw_buttons(wm, c);
    client_draw_border(wm, c);
}


/*
 * Update cursor based on position relative to window
 */
void
client_update_cursor(WM * wm, Client * c, Window w, int x, int y) {
  int edge;
  Cursor cursor;

  if (c == NULL) {
    return;
  }

  /* Only change cursor on frame window */
  if (w != c -> frame) {
    return;
  }

  edge = client_get_resize_edge(wm, c, x, y);

  /* Select appropriate cursor */
  switch (edge) {
  case RESIZE_TOP:
  case RESIZE_BOTTOM:
    cursor = wm -> cursor_resize_ns;
    break;

  case RESIZE_LEFT:
  case RESIZE_RIGHT:
    cursor = wm -> cursor_resize_ew;
    break;

  case RESIZE_TOP_LEFT:
  case RESIZE_BOTTOM_RIGHT:
    cursor = wm -> cursor_resize_nwse;
    break;

  case RESIZE_TOP_RIGHT:
  case RESIZE_BOTTOM_LEFT:
    cursor = wm -> cursor_resize_nesw;
    break;

  default:
    cursor = wm -> cursor_normal;
    break;
  }

  XDefineCursor(wm -> display, c -> frame, cursor);
}