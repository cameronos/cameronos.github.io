/*
 * menu.c - Root menu implementation
 *
 * Handles the right-click root menu, reads ~/.sunrc configuration.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include "sunwm.h"

/* Forward declaration of helper functions */
void menu_draw(WM * wm);
void menu_add_default(WM * wm);
unsigned long get_color_safe(Display * display, int screen,
  const char * color_name);

/*
 * Initialize the root menu
 */
void menu_init(WM * wm) {
  XSetWindowAttributes attrs;

  memset( & wm -> menu, 0, sizeof(Menu));
  wm -> menu.title = strdup("Menu");

  // Create menu window
  attrs.override_redirect = True;
  attrs.background_pixel = wm -> title_bg_inactive;
  // Don't set border_pixel here - colors aren't loaded yet
  attrs.event_mask = ExposureMask | ButtonPressMask | PointerMotionMask | LeaveWindowMask;

  wm -> menu.window = XCreateWindow(wm -> display, wm -> root,
    0, 0, MENU_WIDTH, 100,
    wm->border_width,  /* Use configurable border width */
    CopyFromParent, InputOutput,
    CopyFromParent,
    CWOverrideRedirect | CWBackPixel | CWEventMask, &  // Removed CWBorderPixel
    attrs);

  wm -> menu.visible = 0;
  wm -> menu.selected = -1;
  wm -> menu.num_items = 0;
}

/*
 * Cleanup menu resources
 */
void menu_cleanup(WM * wm) {
  int i;

  if (wm -> menu.title != NULL) {
    free(wm -> menu.title);
    wm -> menu.title = NULL;
  }

  for (i = 0; i < wm -> menu.num_items; i++) {
    if (wm -> menu.items[i].label != NULL) {
      free(wm -> menu.items[i].label);
    }
    if (wm -> menu.items[i].command != NULL) {
      free(wm -> menu.items[i].command);
    }
  }

  XDestroyWindow(wm -> display, wm -> menu.window);
}

void grab_shortcut(WM *wm, unsigned int modifiers, KeySym keysym) {
    KeyCode keycode = XKeysymToKeycode(wm->display, keysym);
    if (keycode == 0) return;

    // Grab key for all common modifier combinations (NumLock / CapsLock)
    unsigned int mods[] = {
        modifiers,
        modifiers | Mod2Mask,       // NumLock
        modifiers | LockMask,       // CapsLock
        modifiers | Mod2Mask | LockMask
    };

    for (int i = 0; i < 4; i++) {
        XGrabKey(wm->display, keycode, mods[i], wm->root, True,
                 GrabModeAsync, GrabModeAsync);
    }
}


/*
 * Load menu configuration from ~/.sunrc
 */
/*
 * Load menu configuration from ~/.sunrc
 */
void menu_load_rc(WM *wm) {
    FILE *debug = fopen("/tmp/sunwm-debug.log", "w");
    if (debug) fprintf(debug, "=== Loading shortcuts ===\n");

    // Free old menu items
    for (int i = 0; i < wm->menu.num_items; i++) {
        free(wm->menu.items[i].label);
        free(wm->menu.items[i].command);
    }
    wm->menu.num_items = 0;
    wm->menu.selected = -1;

    // Free old shortcuts
    for (int i = 0; i < wm->num_shortcuts; i++) {
        free(wm->shortcuts[i].command);
    }
    wm->num_shortcuts = 0;

    char path[1024];
    char line[256];
    char *home = getenv("HOME");
    if (!home) {
        fprintf(stderr, "Cannot get HOME directory\n");
        if (debug) fclose(debug);
        return;
    }
    
        // Initialize border colors to default values if not set
    if (wm->border_active == 0) {
        wm->border_active = wm->title_bg_active;
    }
    if (wm->border_inactive == 0) {
        wm->border_inactive = wm->title_bg_inactive;
    }

    snprintf(path, sizeof(path), "%s/%s", home, RC_FILE);
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "No %s found, creating default menu\n", path);
        menu_add_default(wm);
        if (debug) fclose(debug);
        return;
    }
   

    while (fgets(line, sizeof(line), fp)) {
        // Skip comments and empty lines
        if (line[0] == '#' || line[0] == '\n') continue;
        
        // Remove newline
        char *newline = strchr(line, '\n');
        if (newline) *newline = '\0';

        // Find the colon separator
        char *colon = strchr(line, ':');
        if (!colon) continue;

        *colon = '\0';
        char *label = line;
        char *value = colon + 1;

        // Trim whitespace from label
        while (*label == ' ' || *label == '\t') label++;
        char *end_label = label + strlen(label) - 1;
        while (end_label >= label && (*end_label == ' ' || *end_label == '\t')) {
            *end_label = '\0';
            end_label--;
        }

        // Trim leading whitespace from value
        while (*value == ' ' || *value == '\t') value++;

        // Handle special directives
        if (strcasecmp(label, "Title") == 0) {
            free(wm->menu.title);
            wm->menu.title = strdup(value);
            continue;
        }

        // Handle colors
        if (strncasecmp(label, "color.", 6) == 0) {
            unsigned long color = get_color_safe(wm->display, wm->screen, value);
            
            // Add debug output
            if (debug) {
                fprintf(debug, "Color setting: %s = %s (value: %lu)\n", label, value, color);
            }
            
            if (strcasecmp(label, "color.background") == 0) {
                wm->bg_color = color;
                XSetWindowBackground(wm->display, wm->root, wm->bg_color);
                XSetWindowBackground(wm->display, wm->menu.window, wm->bg_color);
                XClearWindow(wm->display, wm->menu.window);
            } else if (strcasecmp(label, "color.title_active") == 0) wm->title_bg_active = color;
            else if (strcasecmp(label, "color.title_inactive") == 0) wm->title_bg_inactive = color;
            else if (strcasecmp(label, "color.title_text") == 0) wm->title_fg = color;
            else if (strcasecmp(label, "color.border_light") == 0) wm->border_light = color;
            else if (strcasecmp(label, "color.border_dark") == 0) wm->border_dark = color;
            else if (strcasecmp(label, "color.border_active") == 0) wm->border_active = color;
            else if (strcasecmp(label, "color.border_inactive") == 0) wm->border_inactive = color;
            continue;
        }
        
        // Handle border width
        if (strcasecmp(label, "border_width") == 0) {
            int width = atoi(value);
            if (width >= 0 && width <= 20) {  // Reasonable limits
                wm->border_width = width;
            }
            continue;
        }

        // Parse menu item with optional keyboard shortcut
        // Format: "command ; key.Modifier+Key"
        char *command = value;
        char *shortcut_spec = NULL;
        
        // Look for "; key." pattern
        char *key_marker = strstr(value, "; key.");
        if (key_marker) {
            // Split at the semicolon
            *key_marker = '\0';
            command = value;
            shortcut_spec = key_marker + 6; // Skip "; key." to get to the key spec
            
            // Trim trailing whitespace from command
            char *end_cmd = command + strlen(command) - 1;
            while (end_cmd >= command && (*end_cmd == ' ' || *end_cmd == '\t')) {
                *end_cmd = '\0';
                end_cmd--;
            }
        }

        // Add menu item
        if (wm->menu.num_items < MAX_MENU_ITEMS) {
            wm->menu.items[wm->menu.num_items].label = strdup(label);
            wm->menu.items[wm->menu.num_items].command = strdup(command);
            wm->menu.num_items++;
        }

        // Parse keyboard shortcut if present
        if (shortcut_spec) {
            unsigned int modifiers = 0;
            
            if (debug) {
                fprintf(debug, "\nParsing shortcut for: %s\n", label);
                fprintf(debug, "  Full spec: '%s'\n", shortcut_spec);
            }
            
            // Check for each modifier
            if (strstr(shortcut_spec, "Ctrl+") || strstr(shortcut_spec, "Control+")) {
                modifiers |= ControlMask;
            }
            if (strstr(shortcut_spec, "Alt+") || strstr(shortcut_spec, "Mod1+")) {
                modifiers |= Mod1Mask;
            }
            if (strstr(shortcut_spec, "Shift+")) {
                modifiers |= ShiftMask;
            }
            if (strstr(shortcut_spec, "Super+") || strstr(shortcut_spec, "Mod4+")) {
                modifiers |= Mod4Mask;
            }

            // Find the key name (everything after the last '+')
            char *key_name = strrchr(shortcut_spec, '+');
            if (key_name) {
                key_name++;  // Skip the '+'
            } else {
                key_name = shortcut_spec;  // No '+' means no modifiers
            }

            // Trim whitespace from key name
            while (*key_name == ' ' || *key_name == '\t') key_name++;
            char *end_key = key_name + strlen(key_name) - 1;
            while (end_key >= key_name && (*end_key == ' ' || *end_key == '\t')) {
                *end_key = '\0';
                end_key--;
            }

            // Convert single-letter keys to lowercase for proper KeySym lookup
            // Multi-character special keys like "Return" should stay as-is
            if (strlen(key_name) == 1) {
                key_name[0] = tolower((unsigned char)key_name[0]);
            }

            // Convert key name to KeySym
            KeySym keysym = XStringToKeysym(key_name);
            
            if (debug) {
                fprintf(debug, "  Key name: '%s'\n", key_name);
                fprintf(debug, "  KeySym: %lu\n", keysym);
                fprintf(debug, "  Modifiers: %u (Ctrl=%d Alt=%d Shift=%d Super=%d)\n",
                        modifiers,
                        !!(modifiers & ControlMask),
                        !!(modifiers & Mod1Mask),
                        !!(modifiers & ShiftMask),
                        !!(modifiers & Mod4Mask));
            }

            // Only register shortcuts with valid keysyms and at least one modifier
            if (keysym != NoSymbol && modifiers != 0 && wm->num_shortcuts < MAX_SHORTCUTS) {
                wm->shortcuts[wm->num_shortcuts].modifiers = modifiers;
                wm->shortcuts[wm->num_shortcuts].keysym = keysym;
                wm->shortcuts[wm->num_shortcuts].command = strdup(command);

                grab_shortcut(wm, modifiers, keysym);
                wm->num_shortcuts++;
                
                if (debug) {
                    fprintf(debug, "  ✓ Registered shortcut #%d\n", wm->num_shortcuts - 1);
                }
            } else {
                if (debug) {
                    if (keysym == NoSymbol) {
                        fprintf(debug, "  ✗ Invalid key name\n");
                    } else if (modifiers == 0) {
                        fprintf(debug, "  ✗ No modifiers (safety check - need at least one modifier)\n");
                    }
                }
            }
        }
    }

    fclose(fp);

    if (debug) {
        fprintf(debug, "\n=== Total shortcuts registered: %d ===\n", wm->num_shortcuts);
        fclose(debug);
    }

    if (wm->menu.num_items == 0) {
        menu_add_default(wm);
    }
    
    // Set menu border color now that colors are loaded
    XSetWindowBorder(wm->display, wm->menu.window, wm->border_dark);
}

/*
 * Add default menu items
 */
void menu_add_default(WM * wm) {
  wm -> menu.items[0].label = strdup("Terminal");
  wm -> menu.items[0].command = strdup("xterm &");
  wm -> menu.items[1].label = strdup("Clock");
  wm -> menu.items[1].command = strdup("xclock &");
  wm -> menu.items[2].label = strdup("Calculator");
  wm -> menu.items[2].command = strdup("xcalc &");
  wm -> menu.items[3].label = strdup("Exit");
  wm -> menu.items[3].command = strdup("exit");
  wm -> menu.num_items = 4;
}

/*
 * Show menu at specified position
 */
void menu_show(WM * wm, int x, int y) {
  if (wm -> menu.num_items == 0) return;

  int height = wm -> menu.num_items * MENU_ITEM_HEIGHT;

  if (wm -> menu.title && strlen(wm -> menu.title) > 0) {
    height += MENU_ITEM_HEIGHT; // space for title
  }

  XMoveResizeWindow(wm -> display, wm -> menu.window, x, y, MENU_WIDTH, height);
  XMapRaised(wm -> display, wm -> menu.window);

  // Grab pointer
  XGrabPointer(wm -> display, wm -> menu.window, True,
    ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
    GrabModeAsync, GrabModeAsync,
    None, None, CurrentTime);

  wm -> menu.visible = 1;
  wm -> menu.selected = -1;

  menu_draw(wm);
}

/*
 * Hide menu
 */
void menu_hide(WM * wm) {
  if (!wm -> menu.visible) return;
  XUngrabPointer(wm -> display, CurrentTime);
  XUnmapWindow(wm -> display, wm -> menu.window);
  wm -> menu.visible = 0;
  wm -> menu.selected = -1;
}

/*
 * Draw menu with optional title
 */
void menu_draw(WM * wm) {
  if (!wm -> menu.visible) return;

  int i, y;
  int text_x = 10;
  int text_y;
  int offset = 0;

  int menu_height = wm -> menu.num_items * MENU_ITEM_HEIGHT;
  if (wm -> menu.title && wm -> menu.title[0]) {
    menu_height += MENU_ITEM_HEIGHT;
  }

  // Fill the entire menu background with configured bg_color
  XSetForeground(wm -> display, wm -> gc, wm -> bg_color);
  XFillRectangle(wm -> display, wm -> menu.window, wm -> gc,
    0, 0, MENU_WIDTH, menu_height);

  // Draw title if exists
  if (wm -> menu.title && wm -> menu.title[0]) {
    offset = MENU_ITEM_HEIGHT;

    XSetForeground(wm -> display, wm -> gc, wm -> title_bg_active);
    XFillRectangle(wm -> display, wm -> menu.window, wm -> gc,
      0, 0, MENU_WIDTH, MENU_ITEM_HEIGHT);

    XSetForeground(wm -> display, wm -> gc, WhitePixel(wm->display, wm->screen));
    text_y = (MENU_ITEM_HEIGHT + wm -> font -> ascent - wm -> font -> descent) / 2;
    XDrawString(wm -> display, wm -> menu.window, wm -> gc,
      text_x, text_y, wm -> menu.title, strlen(wm -> menu.title));
  }

  // Draw each menu item
  for (i = 0; i < wm -> menu.num_items; i++) {
    y = i * MENU_ITEM_HEIGHT + offset;

    // Set item background (highlight if selected)
    unsigned long item_bg = (i == wm -> menu.selected) ? wm -> title_bg_active : wm -> bg_color;
    XSetForeground(wm -> display, wm -> gc, item_bg);
    XFillRectangle(wm -> display, wm -> menu.window, wm -> gc,
      0, y, MENU_WIDTH, MENU_ITEM_HEIGHT);

    // Draw 3D box for item
    draw_3d_box(wm -> display, wm -> menu.window, wm -> gc,
      2, y + 2, MENU_WIDTH - 4, MENU_ITEM_HEIGHT - 4,
      wm -> border_dark, wm -> border_dark, i == wm -> menu.selected);

    // Draw item text
    XSetForeground(wm -> display, wm -> gc, wm -> title_fg);
    text_y = y + (MENU_ITEM_HEIGHT + wm -> font -> ascent - wm -> font -> descent) / 2;
    XDrawString(wm -> display, wm -> menu.window, wm -> gc,
      text_x, text_y,
      wm -> menu.items[i].label,
      strlen(wm -> menu.items[i].label));

    // Look for and display shortcut for this menu item
    for (int j = 0; j < wm -> num_shortcuts; j++) {
      if (strcmp(wm -> shortcuts[j].command, wm -> menu.items[i].command) == 0) {
        // Build shortcut string
        char shortcut_str[64] = "";
        int has_mod = 0;
        
        if (wm -> shortcuts[j].modifiers & ControlMask) {
          strcat(shortcut_str, "Ctrl+");
          has_mod = 1;
        }
        if (wm -> shortcuts[j].modifiers & Mod1Mask) {
          strcat(shortcut_str, "Alt+");
          has_mod = 1;
        }
        if (wm -> shortcuts[j].modifiers & ShiftMask) {
          strcat(shortcut_str, "Shift+");
          has_mod = 1;
        }
        if (wm -> shortcuts[j].modifiers & Mod4Mask) {
          strcat(shortcut_str, "Super+");
          has_mod = 1;
        }
        
        // Add the key name
        char *keyname = XKeysymToString(wm -> shortcuts[j].keysym);
        if (keyname) {
          strcat(shortcut_str, keyname);
          
          // Draw shortcut text (dimmed/lighter color)
          // Mix title_fg with bg_color for a lighter shade
          unsigned long dimmed_color = wm -> border_light;
          XSetForeground(wm -> display, wm -> gc, dimmed_color);
          
          int shortcut_width = XTextWidth(wm -> font, shortcut_str, strlen(shortcut_str));
          int shortcut_x = MENU_WIDTH - shortcut_width - 15; // Right-aligned with padding
          
          XDrawString(wm -> display, wm -> menu.window, wm -> gc,
            shortcut_x, text_y,
            shortcut_str, strlen(shortcut_str));
        }
        break; // Only show first matching shortcut
      }
    }
  }
}

int menu_hit_test(WM *wm, int y) {
    int offset = 0;
    if (wm->menu.title && wm->menu.title[0]) {
        offset = MENU_ITEM_HEIGHT; // title area
    }

    if (y < offset) return -1; // title is not clickable

    int item = (y - offset) / MENU_ITEM_HEIGHT;

    if (item < 0 || item >= wm->menu.num_items) return -1;

    return item;
}


void menu_handle_button_press(WM *wm, XButtonEvent *ev) {
    if (!wm->menu.visible) return;

    int item = menu_hit_test(wm, ev->y);
    if (item >= 0) menu_execute(wm, item);

    menu_hide(wm);
}

void menu_handle_motion(WM *wm, XMotionEvent *ev) {
    if (!wm->menu.visible) return;

    int item = menu_hit_test(wm, ev->y);
    if (item != wm->menu.selected) {
        wm->menu.selected = item;
        menu_draw(wm);
    }
}

/*
 * Execute selected menu item
 */
void menu_execute(WM *wm, int item) {
    if (item < 0 || item >= wm->menu.num_items) return;

    char *command = wm->menu.items[item].command;
    if (!command || strlen(command) == 0) return;

    // Handle special commands
    if (strcmp(command, "exit") == 0) {
        wm_cleanup(wm);
        exit(0);
    }

if (strcmp(command, "refresh") == 0 || strcmp(command, "sunwm-refresh") == 0) {
    // Reload config
    menu_load_rc(wm);

    // Clear root window to background color
    XSetWindowBackground(wm->display, wm->root, wm->bg_color);
    XClearWindow(wm->display, wm->root);
    XSync(wm->display, False);

    for (Client *c = wm->clients; c != NULL; c = c->next) {
        // Update frame border width to new configured value
        XSetWindowBorderWidth(wm->display, c->frame, wm->border_width);
        
        // Update frame border color based on focus state
        XSetWindowBorder(wm->display, c->frame, 
            (c == wm->focused) ? wm->border_active : wm->border_inactive);

        // Update title and buttons
        XSetWindowBackground(wm->display, c->title,
            (c == wm->focused) ? wm->title_bg_active : wm->title_bg_inactive);
        XSetWindowBackground(wm->display, c->close_button,
            (c == wm->focused) ? wm->title_bg_active : wm->title_bg_inactive);
        XSetWindowBackground(wm->display, c->maximize_button,
            (c == wm->focused) ? wm->title_bg_active : wm->title_bg_inactive);

        // Clear windows so new colors appear
        XClearWindow(wm->display, c->frame);
        XClearWindow(wm->display, c->title);
        XClearWindow(wm->display, c->close_button);
        XClearWindow(wm->display, c->maximize_button);

        // Redraw decorations
        client_draw_title(wm, c);
        client_draw_buttons(wm, c);

        // Map all windows to ensure visibility
        XMapWindow(wm->display, c->frame);
        XMapWindow(wm->display, c->title);
        XMapWindow(wm->display, c->close_button);
        XMapWindow(wm->display, c->maximize_button);
    }
    
    // Update menu window border width and color
    XSetWindowBorderWidth(wm->display, wm->menu.window, wm->border_width);
    // Note: menu_load_rc() already sets the border color, but this ensures it's applied


    // Redraw menu if it's visible
    if (wm->menu.visible) {
        menu_draw(wm);
    }

    XSync(wm->display, False);
    return;
}

    // Run external command
    pid_t pid = fork();
    if (pid == 0) {
        // Child process
        setsid();  // detach from WM

        // Use execlp so it searches $PATH and works for shortcuts
        if (execlp("/bin/sh", "sh", "-c", command, NULL) < 0) {
            perror("execlp failed");  // helpful error if something goes wrong
        }
        _exit(1);
    } else if (pid < 0) {
        // Fork failed
        perror("fork failed");
    }
    // Parent continues normally
}

unsigned long get_color_safe(Display * display, int screen,
  const char * color_name) {
  XColor color;
  Colormap colormap = DefaultColormap(display, screen);

  if (color_name[0] == '#') {
    // Convert #RRGGBB to XColor
    unsigned int r, g, b;
    if (sscanf(color_name + 1, "%02x%02x%02x", & r, & g, & b) == 3) {
      color.red = r << 8; // X11 expects 16-bit values
      color.green = g << 8;
      color.blue = b << 8;
      color.flags = DoRed | DoGreen | DoBlue;
      if (XAllocColor(display, colormap, & color)) {
        return color.pixel;
      }
    }
  }

  // fallback to named color
  if (!XParseColor(display, colormap, color_name, & color) || !XAllocColor(display, colormap, & color)) {
    return 0xFFFFFF; // fallback white
  }

  return color.pixel;
}