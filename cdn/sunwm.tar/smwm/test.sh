#!/bin/bash
#
# test_sunwm.sh - Test SunWM in Xephyr
#
# This script launches Xephyr and runs SunWM with some test applications
#

echo "SunWM Test Script"
echo "================="
echo ""
echo "This will launch Xephyr with SunWM and some test applications."
echo ""

# Check if Xephyr is installed
if ! command -v Xephyr &> /dev/null; then
    echo "Error: Xephyr is not installed."
    echo "Install it with: sudo apt-get install xserver-xephyr"
    exit 1
fi

# Kill any existing Xephyr on :1
pkill -f "Xephyr :2" 2>/dev/null

# Start Xephyr
echo "Starting Xephyr on display :2..."
Xephyr -screen 1024x768 :2 &
XEPHYR_PID=$!

# Wait for Xephyr to start
sleep 2

# Start SunWM
echo "Starting SunWM..."
DISPLAY=:2 ./sunwm &
WM_PID=$!

# Wait for WM to initialize
sleep 1

# Launch test applications
echo "Launching test applications..."
DISPLAY=:2 xterm -bg black -fg white -geometry 80x24+50+50 &
sleep 0.5
DISPLAY=:2 xclock -geometry 200x200+400+100 &
sleep 0.5
DISPLAY=:2 xeyes -geometry 150x100+200+300 &

echo ""
echo "SunWM is now running in Xephyr!"
echo ""
echo "Tips:"
echo "  - Click and drag title bars to move windows"
echo "  - Press Alt+Tab to switch between windows"
echo "  - Close this terminal or press Ctrl+C to stop"
echo ""
echo "Press Ctrl+C to stop..."

# Wait for user interrupt
trap "echo ''; echo 'Cleaning up...'; kill $WM_PID $XEPHYR_PID 2>/dev/null; exit 0" INT

wait $XEPHYR_PID
